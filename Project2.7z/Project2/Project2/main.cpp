#include "series.h"
#include <iostream>

void main() {
	double limit;
	std::cout << "Please enter a limit value" << std::endl;
	std::cin >> limit;
	SERIES s = EXP;
	int length;
	double* values = getSeries(s, limit, length);
}