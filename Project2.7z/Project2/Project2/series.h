#include <iostream>
#include <vector>


enum SERIES {
	LOG, EXP, FIB, FAC
};

double* getSeries( SERIES _s, double _limit, int& length );
double mean (double* _values, int length ) ;
void printSeries (double* _first, double* last);

