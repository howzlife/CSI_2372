#include "Customer.h"
#include "Service.h"


int main()
{
	Service* service = new Service(); //new first 10

	//add three customer
	for (int i = 0; i < 10; i++)
	{
		service->addCustomer();
		service->addCustomer();
		service->addCustomer();
		service->serve();
		service->display();
	}

	return 0;
}