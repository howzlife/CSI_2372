#include "Customer.h"
#include <stdlib.h>     /* srand, rand */
#include <time.h>  
Customer::Customer(int number)
{
	Item_number = number;
}

Customer::~Customer()
{
	Item_number = 0;
}

bool Customer::served()
{
	bool result = false;
	Item_number -= 10;
	if (Item_number <= 0)
		result = true;
	return result;
}