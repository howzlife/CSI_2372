
#include "Customer.h"
#include "Service.h"
#include <stdlib.h>     /* srand, rand */
#include <time.h>  
Service::Service()
{
	srand(time(NULL));
	for (int i = 0; i < 10; i++)
	{
		int radnom = rand() % 100 + 1;
		customers.push_back(new Customer(radnom));
	}
}

Service::~Service()
{
	for (Customer* customer : customers)
	{
		delete customer;
		customer = NULL;
	}
	//delete every element in array
	customers.clear();
}

void Service::addCustomer()
{
	int radnom = rand() % 100 + 1;
	customers.push_back(new Customer(radnom));
}

void Service::serve()
{
	int size = customers.size();
	for (int i = 0; i < size; i++)
	{
		if (customers[i]->served() == true)
		{
			delete customers[i];
			customers[i] = NULL;

			// erase the customer
			customers.erase(customers.begin() + i);

			//move data and calculate new size
			size = customers.size();
		}
	}
}

void Service::display()
{
	int size = customers.size();
	int point[100];
	for (int j = 0; j< 100; j++)
	{
		point[j] = 0;
	}
	for (int i = 0; i < size; i++)
	{
		point[customers[i]->Item_number - 1] ++;
	}

	//display
	for (int k = 0; k< 100; k++)
	{
		if (point[k] > 0)
			cout << "point " << k + 1 << " has " << point[k] << " customers" << endl;
	}
	cout << "display end" << endl << endl;
}

int Service::max()
{
	return customers.max_size();
}