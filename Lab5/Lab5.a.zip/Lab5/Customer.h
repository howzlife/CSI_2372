#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <iostream>
using namespace std;
class Customer
{
public:
	Customer(int number);
	~Customer();
	bool served();
	int Item_number;
};

#endif